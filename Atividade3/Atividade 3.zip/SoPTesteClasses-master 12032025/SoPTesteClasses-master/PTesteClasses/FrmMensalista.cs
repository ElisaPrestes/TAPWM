﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteClasses
{
    public partial class FrmMensalista : Form
    {
        public FrmMensalista()
        {
            InitializeComponent();
        }

        private void FrmMensalista_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();
            
            objMensalista.NomeEmpregado = txtNome.Text;
            objMensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txtSalario.Text);

            MessageBox.Show("Nome = " + objMensalista.NomeEmpregado + "\n" +
                "Matricula = " + objMensalista.Matricula + "\n" +
                "Tempo de Trabalho = " + objMensalista.TempoTrabalho() + "\n" +
                "Sálario Final = " + objMensalista.SalarioBruto().ToString("N2"));

            MessageBox.Show("Empresa: " + Mensalista.empresa);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Mensalista ObjMensalista = new Mensalista(
                Convert.ToInt32(txtMatricula.Text),
                txtNome.Text,
                Convert.ToDateTime(txtData.Text),
                Convert.ToDouble(txtSalario.Text)
                );

            //mostrando valores
            MessageBox.Show("Nome: " + ObjMensalista.NomeEmpregado +
                "\n" + "Matricula: " + ObjMensalista.Matricula + "\n" +
                "Tempo trabalhado: " + ObjMensalista.TempoTrabalho() +
                "\n" + "Salário: " + ObjMensalista.SalarioBruto().ToString("N2"));
        }
    }
    //private vale apenas dentro da p´ropria classe;
    //public vale no msm projeto, em diferentes projetos e fora da própria classe;
    //internal não se vê fora do projeto. apenas dentro do projeto;
    //Internal se vê dentro das classes derivadas.

    //namespaces -> Exemplo: System.Windows.Show

}
